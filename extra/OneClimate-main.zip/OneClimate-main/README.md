# OneClimate
## EECS 373 Embedded System Design Final Project
### Authored by Matthew Artaega, Eli Gooding, and Broderick Riopelle
