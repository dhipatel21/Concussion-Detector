#include <TS.h>
#include "stm32l4xx_hal.h"
#include <stdlib.h>

void ADC_Select(ADC_HandleTypeDef *hadc, uint32_t channel, GPIO_TypeDef* port, uint32_t pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	ADC_ChannelConfTypeDef sConfig = {0};

	GPIO_InitStruct.Pin = pin;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(port, &GPIO_InitStruct);

	sConfig.Channel = channel;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_640CYCLES_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;
	HAL_ADC_ConfigChannel(hadc, &sConfig);
}

double TS_readPressure(ADC_HandleTypeDef *hadc)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

		// Pull X+ low  and Y- high to get voltage differential
		GPIO_InitStruct.Pin = XPOS_PIN;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(X_PORT, &GPIO_InitStruct);
		HAL_GPIO_WritePin(X_PORT, XPOS_PIN, GPIO_PIN_RESET);

		GPIO_InitStruct.Pin = YNEG_PIN;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(Y_PORT, &GPIO_InitStruct);
		HAL_GPIO_WritePin(Y_PORT, YNEG_PIN, GPIO_PIN_SET);

		// Set proper ADC channel
		ADC_Select(hadc, XNEG_ADC_CHANNEL, X_PORT, XPOS_PIN);

		// Read ADC
		int32_t z1 = 0, z2 = 0;
		for (int i = 0; i < ADC_SAMPLE_COUNT; ++i)
		{
			HAL_ADC_Start(hadc);
			HAL_ADC_PollForConversion(hadc, 100);
			z1 += HAL_ADC_GetValue(hadc);
			HAL_ADC_Stop(hadc);
		}
		z1 /= ADC_SAMPLE_COUNT;

		// Set proper ADC channel
		ADC_Select(hadc, YPOS_ADC_CHANNEL, Y_PORT, YPOS_PIN);

		for (int i = 0; i < ADC_SAMPLE_COUNT; ++i)
		{
			HAL_ADC_Start(hadc);
			HAL_ADC_PollForConversion(hadc, 100);
			z2 += HAL_ADC_GetValue(hadc);
			HAL_ADC_Stop(hadc);
		}
		z2 /= ADC_SAMPLE_COUNT;

		// Return X+ and Y- to high impedance state
		ADC_Select(hadc, XPOS_ADC_CHANNEL, X_PORT, XPOS_PIN);
		ADC_Select(hadc, YNEG_ADC_CHANNEL, Y_PORT, YNEG_PIN);

		return z2 - z1;
}
